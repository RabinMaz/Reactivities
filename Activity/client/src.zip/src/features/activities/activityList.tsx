import { Box } from "@mui/material";
import ActivityCard from "./activityCard";
type activities = {
    activities:Activity[];
    selectActivity: (id:string)=>void;
}

const ActivityList = ({activities,selectActivity}:activities) => {
  return (
    <Box sx={{display:'flex', flexDirection:'column', gap:3}}>
       {activities.map(activity=>(
          <ActivityCard key={activity.id} activity={activity} selectActivity={selectActivity}/>
       ))}
    </Box>
  )
};

export default ActivityList;
